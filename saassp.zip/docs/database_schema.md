# SAASSP Database Schema

The tables are defined in `database/schema.sql` (created by `database/load_data.py`)
and match `backend/models.py`. The app connects to PostgreSQL using the `DB_` settings
in `.env`.

## Relationships

```mermaid
erDiagram
    USERS ||--o{ STUDENT_MODULES : enrols_in
    USERS ||--o{ LECTURER_MODULES : teaches
    USERS ||--o{ CHAT_MESSAGES : chats
    USERS ||--o{ ACCESS_REQUESTS : sends
    MODULES ||--o{ ACCESS_REQUESTS : requested
    PROGRAMMES ||--o{ PROGRAMME_MODULES : contains
    MODULES ||--o{ PROGRAMME_MODULES : offered_in
    MODULES ||--o{ LECTURER_MODULES : assigned
    MODULES ||--o{ STUDENT_MODULES : selected
    MODULES ||--o{ MODULE_ASSESSMENT_CONFIGS : weighted_by
    MODULES ||--o{ MODULE_ASSESSMENTS : has
    STUDENT_MODULES ||--o{ ASSESSMENT_MARKS : receives
    ASSESSMENT_MARKS ||--o| FEEDBACK_MESSAGES : gets
```

`lecturer_marks` and `access_logs` deliberately have **no foreign keys**: they
store the student number as text so they survive a student registering late or
deleting their account.

## Tables

| Table | What it holds | Key columns |
|---|---|---|
| `users` | Every account | `id` PK, `name`, `student_number` UQ (students), `email` UQ (staff/admin), `role` (`student` / `academic_staff` / `admin`), `password_hash`, `is_approved` (false only for an admin still waiting for approval) |
| `access_requests` | Lecturer module requests and admin access requests | `user_id` FK users, `request_type` (`module` / `admin`), `module_code` FK (module requests only), `status` (`pending` / `approved` / `rejected`), `created_at`, `decided_at`, `decided_by`; one pending request per user per thing |
| `programmes` | Degree programmes | `programme_code` PK, `programme_name` |
| `modules` | Modules | `module_code` PK, `module_name` |
| `programme_modules` | Which modules belong to which programme | `programme_code` FK, `module_code` FK, UQ(both) |
| `lecturer_modules` | Which modules a lecturer teaches (set by admin) | `lecturer_id` FK users, `module_code` FK, UQ(both) |
| `student_modules` | A student's enrolment in a module | `student_id` FK users, `programme_code` FK, `module_code` FK, UQ(student, module) |
| `module_assessment_configs` | The lecturer's assessment structure per module | `module_code` FK, `category_name`, `dp_weighting` (0–100), `total_assessments`, `recorded_count` (best N), `updated_at`, `updated_by`, UQ(module, category) |
| `module_assessments` | Named assessments, e.g. "Test 1" | `module_code` FK, `category_name`, `label`, UQ(module, label) |
| `assessment_marks` | Marks counted in DP progress | `student_module_id` FK, `category_name`, `percentage_achieved` NUMERIC(5,2), `date_uploaded`, `recorded_towards_dp`, `sequence` (upload order), `source` (`student` / `lecturer`), `assessment_label` |
| `lecturer_marks` | Official marks from lecturer CSV uploads, kept by student number | `module_code`, `student_number`, `category_name`, `assessment_label`, `percentage`, `uploaded_by`, `uploaded_at`, UQ(module, student_number, label) |
| `feedback_messages` | Claude's feedback for a student's mark | `mark_id` FK, `dp_progress_percentage`, `threshold_band`, `trend_classification`, `generated_text`, `created_at` |
| `chat_messages` | Advisor chatbot history | `student_id` FK users, `role` (`user` / `assistant`), `content`, `created_at` |
| `access_logs` | Who viewed which student's record (POPIA) | `viewer_id`, `viewer_name`, `viewer_role`, `student_id`, `student_number`, `module_code`, `action`, `created_at` |

Deleting a user also deletes their enrolments, marks, feedback, chat
messages and requests (cascade). `lecturer_marks` and `access_logs` are kept.
