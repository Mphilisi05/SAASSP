# SAASSP – Smart Academic Advisory & Student Success Platform

A Flask web app for the University of Zululand that tracks each student's
**DP (Duly Performed) progress** per module, gives **AI feedback** after every
mark, and has an **Advisor chatbot**. Both AI features use **Claude (Anthropic)**.

The numbers (DP %, threshold band, trend) are always calculated by normal
Python code in `backend/services/dp_engine.py`. Claude only puts them into
words. Without an API key the app still works, just without AI text.

## Roles

| Role | Logs in with | Can do |
|---|---|---|
| Student | student number | pick programme and modules, enter marks, see DP progress and feedback, chat with the Advisor |
| Lecturer (academic staff) | e-mail | request the modules they teach, set the assessment structure of their modules, upload official marks from CSV, view their own students (read-only) |
| Admin | e-mail | approve lecturer module requests and new admin requests, import programme/module data, manage accounts, view the access log |

## Accounts and requests

- Anyone can register as a Student, Lecturer or Admin.
- **Main admin:** the account registered (as Admin) with the `ADMIN_EMAIL` from `.env`
  is an approved admin immediately. It cannot be removed or demoted, and if an account
  with that e-mail already exists it is made admin when the app starts.
- **Other admins** start with no admin rights. Their only page has a
  *Request admin access* button. An approved admin accepts or rejects the request
  under **Requests**. Once accepted, the request page and button are gone; if rejected,
  they can ask again.
- **Lecturers** pick the module(s) they teach on **Request Modules** and send a
  request. They can request more modules at any time. Each module appears under
  *My Modules & Students* once an admin approves it.
- Students have no request pages.

## Project structure

```
saassp/
  app.py                  entry point: creates the Flask app and registers routes
  config.py               settings, read from .env
  requirements.txt
  .env.example            copy to .env and fill in
  backend/
    __init__.py           shared db + login manager
    models.py             database tables
    wsgi.py               WSGI entry (Vercel / gunicorn)
    routes/               pages and actions, one file per role
      auth.py               login, register, admin access request, password reset/change
      student.py            dashboard, modules, mark upload, Advisor chat
      staff.py              lecturer: module requests, structure, CSV marks, student views
      admin.py              requests (approve/reject), programmes, users, access log
    services/             logic used by the routes
      dp_engine.py          DP calculation, bands, trends (pure Python, no DB, no AI)
      progress.py           connects the DB models to dp_engine
      claude_client.py      the single place that calls Claude
      feedback_service.py   per-mark AI feedback
      advisor_chat.py       Advisor chatbot (sees only the logged-in student's data)
      mailer.py             password-reset e-mails
      access_log.py         records who viewed which student
  templates/              HTML pages (Jinja2 + Bootstrap), grouped by role
    base.html  auth/  student/  staff/  admin/
  static/                 css/, img/
  data/                   programmes.csv, modules.csv, programme_modules.csv
  database/               PostgreSQL scripts
    load_data.py            creates/upgrades the tables and loads data/*.csv
    schema.sql              the 14 tables (safe to rerun; used by load_data.py)
    create_database.sql     optional: creates the SASSP database without pgAdmin
    drop_tables.sql         removes all tables and data (start over)
  docs/database_schema.md
  tests/                  test_dp_engine.py (unit), test_app_smoke.py (full flows)
```

## Setup

1. Create an empty PostgreSQL database called `SASSP` (in pgAdmin, or with
   `psql -U postgres -f database/create_database.sql`).
2. Install and configure:

```bash
python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                # Windows: copy .env.example .env
```

   Then fill in `.env`: `SECRET_KEY`, the five `DB_` settings, `ADMIN_EMAIL` and `ANTHROPIC_API_KEY`.

3. Fill the database and start the app:

```bash
python database/load_data.py        # creates/upgrades tables, loads programmes, modules, links
python app.py                       # http://localhost:5000
```

4. Open the app, choose **Create account**, pick **Admin** and register with your
   `ADMIN_EMAIL`. That is the main admin. Everyone else registers the same way.

After updating to a new version, run `python database/load_data.py` again: it adds any
new tables or columns and keeps your data.

## Settings (.env)

| Key | Needed | What it is |
|---|---|---|
| `SECRET_KEY` | yes | signs login sessions; any long random string |
| `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` | yes | PostgreSQL connection |
| `ADMIN_EMAIL` | yes | e-mail of the main System Administrator |
| `ANTHROPIC_API_KEY` | for AI | Claude key; without it the app works with no AI text |
| `ANTHROPIC_MODEL` | no | Claude model, default `claude-haiku-5-5` |
| `ANTHROPIC_CHAT_MODEL` | no | separate model for the chatbot, e.g. `claude-sonnet-5-5` |
| `FLASK_DEBUG`, `FLASK_RUN_HOST`, `FLASK_RUN_PORT` | no | debug mode (0/1), address and port, default `0`, `0.0.0.0`, `5000` |
| `MAIL_SERVER`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM` | no | SMTP for password-reset e-mails; empty = link printed in the terminal |

## How DP progress is calculated

For each category with a weighting above 0, the student's best N marks count
(N = "recorded count" set by the lecturer). Each slot is worth
`weighting / N` points.
`DP % = points earned / points attempted × 100`. That is progress on what has
been written **so far**. The result maps to six bands: Very safe (75+), Safe
(70–75), Generally safe (60–70), Pass with some risk (50–60), Danger (40–50)
and Critical (below 40).
A lecturer's CSV mark for an assessment replaces the student's own entry for
the same assessment.

## Tests

```bash
pytest tests -v
```

Tests use an in-memory SQLite database by default. To run them on PostgreSQL,
point `TEST_DATABASE_URL` at an empty throwaway database (it is wiped after each test).

## Before a real deployment

- Add CSRF protection (Flask-WTF).
- Set a strong `SECRET_KEY` and keep `FLASK_DEBUG=0`.
