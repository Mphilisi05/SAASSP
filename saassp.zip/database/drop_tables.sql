-- WARNING: deletes ALL SAASSP tables and data. Only for starting over.
-- psql -U postgres -d SASSP -f database/drop_tables.sql

DROP TABLE IF EXISTS
    access_requests, feedback_messages, assessment_marks, lecturer_marks, chat_messages, access_logs,
    module_assessments, module_assessment_configs, student_modules, lecturer_modules,
    users, programme_modules, modules, programmes
CASCADE;
