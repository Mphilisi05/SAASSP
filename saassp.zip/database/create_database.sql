-- Optional: creates the database if you are not using pgAdmin.
-- Run as the postgres user:  psql -U postgres -f database/create_database.sql
-- The quotes keep the capital letters, so it matches DB_NAME=SASSP in .env.

CREATE DATABASE "SASSP" ENCODING 'UTF8';
