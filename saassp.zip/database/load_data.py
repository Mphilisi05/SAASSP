# Takes every CSV file in the data/ folder and inserts it into the table with
# the same name (programmes.csv -> programmes). First runs schema.sql, which
# creates any missing tables or columns (so it also upgrades an older database).
# Safe to run again: rows already there are skipped.
#
# Usage (from the project root):
#   python database/load_data.py
# Connection details come from .env:
#   DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT

import csv
import os
import sys

import psycopg2
from dotenv import load_dotenv

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.path.join(ROOT, "data")
SCHEMA_FILE = os.path.join(ROOT, "database", "schema.sql")

# parent tables must be loaded before the tables that point to them
LOAD_ORDER = ["programmes", "modules", "programme_modules"]


def connect():
    load_dotenv(os.path.join(ROOT, ".env"))
    settings = {
        "dbname": os.environ.get("DB_NAME", ""),
        "user": os.environ.get("DB_USER", ""),
        "password": os.environ.get("DB_PASSWORD", ""),
        "host": os.environ.get("DB_HOST", "localhost"),
        "port": os.environ.get("DB_PORT", "5432"),
    }
    if not settings["dbname"] or not settings["user"]:
        sys.exit("DB_NAME and DB_USER must be set in .env")
    return psycopg2.connect(**settings)


def existing_tables(cur):
    cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
    return {r[0] for r in cur.fetchall()}


def create_or_upgrade_tables(cur):
    # schema.sql only creates what is missing, so this is safe every time
    with open(SCHEMA_FILE, encoding="utf-8") as f:
        sql = f.read()
    # BEGIN/COMMIT in the file are not needed, this script has its own transaction
    sql = sql.replace("BEGIN;", "").replace("COMMIT;", "")
    cur.execute(sql)
    print("Tables checked (missing tables and columns created).")


def table_columns(cur, table):
    cur.execute(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_schema = 'public' AND table_name = %s", (table,))
    return {r[0] for r in cur.fetchall()}


def csv_files_in_order():
    files = {f[:-4]: os.path.join(DATA_DIR, f) for f in os.listdir(DATA_DIR) if f.lower().endswith(".csv")}
    ordered = [t for t in LOAD_ORDER if t in files]
    ordered += sorted(t for t in files if t not in LOAD_ORDER)
    return [(t, files[t]) for t in ordered]


def load_csv(cur, table, path, tables):
    if table not in tables:
        print(f"{os.path.basename(path)}: no table called {table}, skipped")
        return

    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        headers = [h.strip() for h in (reader.fieldnames or [])]
        valid = table_columns(cur, table)
        columns = [h for h in headers if h in valid]
        if not columns:
            print(f"{os.path.basename(path)}: none of its columns match {table}, skipped")
            return

        col_sql = ", ".join(columns)
        marks = ", ".join(["%s"] * len(columns))
        insert = f"INSERT INTO {table} ({col_sql}) VALUES ({marks}) ON CONFLICT DO NOTHING"

        added = already = blank = 0
        failed = []
        for line_no, row in enumerate(reader, start=2):
            row = {(k or "").strip(): v for k, v in row.items()}
            values = [(row.get(c) or "").strip() or None for c in columns]
            if all(v is None for v in values):
                blank += 1
                continue
            # savepoint: one bad row is skipped without undoing the rest
            cur.execute("SAVEPOINT row_sp")
            try:
                cur.execute(insert, values)
                if cur.rowcount:
                    added += 1
                else:
                    already += 1
                cur.execute("RELEASE SAVEPOINT row_sp")
            except psycopg2.Error as e:
                cur.execute("ROLLBACK TO SAVEPOINT row_sp")
                failed.append((line_no, values, e.diag.message_primary))

    print(f"{table}: {added} added, {already} already there or repeated, "
          f"{blank} blank, {len(failed)} failed")
    for line_no, values, reason in failed[:10]:
        print(f"  line {line_no} {values}: {reason}")
    if len(failed) > 10:
        print(f"  ...and {len(failed) - 10} more")


def main():
    if not os.path.isdir(DATA_DIR):
        sys.exit(f"No data folder found at {DATA_DIR}")
    conn = connect()
    try:
        # one transaction: everything is saved, or nothing is
        with conn, conn.cursor() as cur:
            create_or_upgrade_tables(cur)
            tables = existing_tables(cur)
            for table, path in csv_files_in_order():
                load_csv(cur, table, path, tables)
            print("Totals in the database:")
            for table, _ in csv_files_in_order():
                if table in tables:
                    cur.execute(f"SELECT COUNT(*) FROM {table}")
                    print(f"  {table}: {cur.fetchone()[0]}")
        print("Done.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
