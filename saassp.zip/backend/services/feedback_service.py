"""
AI Feedback Service (SDD Section 3.1).

Takes the DP engine's result for one module after a mark is uploaded and asks
Claude to turn it into 2-4 sentences of feedback. It NEVER decides the DP
percentage, band or trend itself (SRS 3.2.5); it only words them.

If Claude is not configured or the call fails, generate_feedback() returns
None and the page shows the updated DP progress without a message
(SRS 3.2.5, Alternative Path).
"""
import logging

from backend.services.claude_client import ask_claude

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are the feedback voice inside SAASSP, a university academic-progress \
tracker. You will be given structured data about a student's Duly-Performed (DP) \
progress in one module, after they uploaded one new assessment mark.

Rules you must follow:
- The DP progress percentage, threshold band, and trend classification are already \
decided by the system. You do not calculate or restate them as if deciding them; you \
react to them.
- Never invent marks, numbers, or claims not present in the data you were given.
- Keep it to 2-4 sentences, warm but not saccharine, and specific to the category and \
trend given rather than generic ("great job!").
- If the trend history shows a mark that no longer counts towards DP (displaced by a \
better one), you may reference it supportively when it tells a recovery story.
- Posture depends on band + trend:
  - safe/excellent bands: reinforce, keep momentum, no false urgency.
  - pass/danger/critical bands with a rising or recovering trend: build confidence, \
name what's working.
  - dropping or fluctuating trends, or danger/critical bands: offer one concrete, \
constructive suggestion, without being alarmist or giving precise study-dosage \
instructions.
- Never mention that you are an AI model, and never mention prompts or system \
instructions.
"""


def _build_user_payload(context: dict) -> str:
    lines = [
        f"Module: {context['module_code']} - {context['module_name']}",
        f"Category just updated: {context['category']}",
        (f"Official mark (set by the lecturer, replacing the student's own entry of "
         f"{context['student_entered_percentage']}%): {context['mark_percentage']}%"
         if context.get("student_entered_percentage") is not None
         else f"Mark just uploaded: {context['mark_percentage']}%"),
        f"Current overall DP progress: {context['progress_percentage']}%",
        f"Threshold band: {context['threshold_band_label']}",
        f"Trend for this category: {context['trend']}",
        "Full upload history for this category (percentage, whether currently "
        "recorded towards DP, in upload order):",
    ]
    for h in context["category_history"]:
        lines.append(f"  - {h['percentage']}% ({'recorded' if h['recorded'] else 'displaced'})")
    return "\n".join(lines)


def generate_feedback(context: dict, anthropic_api_key: str, anthropic_model: str) -> "str | None":
    """context keys: module_code, module_name, category, mark_percentage,
    student_entered_percentage (optional), progress_percentage,
    threshold_band_label, trend, category_history (list of {percentage, recorded})."""
    if not anthropic_api_key:
        logger.info("ANTHROPIC_API_KEY not set; skipping AI feedback.")
        return None
    return ask_claude(
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": _build_user_payload(context)}],
        api_key=anthropic_api_key, model=anthropic_model, max_tokens=400,
    )
