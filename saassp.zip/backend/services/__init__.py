"""Business logic: DP engine, progress helpers, Claude AI, e-mail, access log."""
