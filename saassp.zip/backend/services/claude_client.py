"""
The one place SAASSP talks to Claude (Anthropic).

Both AI features use this:
  * feedback_service.py - short feedback after a mark is uploaded
  * advisor_chat.py     - the student's Advisor chatbot

Claude only WORDS things. Every DP figure, band and trend is worked out by
dp_engine.py first and handed to Claude as data.

If no ANTHROPIC_API_KEY is set, or the call fails (network, rate limit, bad
key), ask_claude() returns None and the caller falls back to a non-AI answer,
so the app never breaks because of the AI.
"""
import logging

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT = 20.0   # seconds
MAX_RETRIES = 1


def _alternating(messages):
    # Claude needs turns that start with the user and alternate user/assistant.
    turns = []
    for m in messages:
        role = "assistant" if m["role"] == "assistant" else "user"
        if not turns and role == "assistant":
            continue
        if turns and turns[-1]["role"] == role:
            turns[-1]["content"] += "\n" + m["content"]
        else:
            turns.append({"role": role, "content": m["content"]})
    return turns


def ask_claude(system, messages, api_key, model, max_tokens=500):
    """messages: list of {"role": "user"|"assistant", "content": str}, oldest first.
    Returns Claude's reply text, or None if Claude is not configured or the call failed."""
    if not api_key or not model:
        return None
    turns = _alternating(messages)
    if not turns:
        return None
    try:
        import anthropic

        client = anthropic.Anthropic(api_key=api_key, timeout=REQUEST_TIMEOUT, max_retries=MAX_RETRIES)
        response = client.messages.create(
            model=model, max_tokens=max_tokens, system=system, messages=turns,
        )
        text = "".join(b.text for b in response.content if getattr(b, "type", "") == "text").strip()
        return text or None
    except Exception as exc:  # network, rate limit, bad key, etc.
        logger.warning("Claude request failed: %s", exc)
        return None
