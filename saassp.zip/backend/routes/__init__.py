"""HTTP routes (Flask blueprints), one module per user role."""
