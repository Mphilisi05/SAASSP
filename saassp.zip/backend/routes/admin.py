"""
See SAASSP_SRS.docx Section 3.2.8, Manage Programme and Module Data, and
Section 3.2.9, Manage User Accounts.
"""
import csv
import io
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, request, flash, abort, current_app
from flask_login import login_required, current_user

from backend import db
from backend.models import User, Programme, Module, ProgrammeModule, LecturerModule, AccessLog, AccessRequest

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def _require_admin():
    # an admin whose own request is still pending has no admin rights yet
    if not current_user.is_admin:
        abort(403)


def _is_main_admin(user):
    main = current_app.config.get("ADMIN_EMAIL", "")
    return bool(main) and (user.email or "") == main


@admin_bp.route("/programmes", methods=["GET", "POST"])
@login_required
def programmes():
    _require_admin()
    if request.method == "POST":
        kind = request.form.get("kind")
        file = request.files.get("csv_file")
        if not file or file.filename == "":
            flash("Choose a CSV file first.", "error")
            return redirect(url_for("admin.programmes"))

        reader = csv.DictReader(io.StringIO(file.stream.read().decode("utf-8-sig")))
        added, skipped = 0, 0

        if kind == "programmes":
            for row in reader:
                code = row.get("programme_code", "").strip()
                name = row.get("programme_name", "").strip()
                if not code or db.session.get(Programme, code):
                    skipped += 1
                    continue
                db.session.add(Programme(programme_code=code, programme_name=name))
                added += 1
        elif kind == "modules":
            for row in reader:
                code = row.get("module_code", "").strip()
                name = row.get("module_name", "").strip()
                if not code or db.session.get(Module, code):
                    skipped += 1
                    continue
                db.session.add(Module(module_code=code, module_name=name))
                added += 1
        elif kind == "links":
            for row in reader:
                p_code = row.get("programme_code", "").strip()
                m_code = row.get("module_code", "").strip()
                if not db.session.get(Programme, p_code) or not db.session.get(Module, m_code):
                    skipped += 1
                    continue  # SRS 3.2.8 Alternative Paths: reject unresolvable references
                exists = ProgrammeModule.query.filter_by(
                    programme_code=p_code, module_code=m_code
                ).first()
                if exists:
                    skipped += 1
                    continue
                db.session.add(ProgrammeModule(programme_code=p_code, module_code=m_code))
                added += 1
        else:
            flash("Unknown import type.", "error")
            return redirect(url_for("admin.programmes"))

        db.session.commit()
        flash(f"Import complete: {added} added, {skipped} skipped.", "success")
        return redirect(url_for("admin.programmes"))

    programmes = Programme.query.order_by(Programme.programme_code).all()
    modules_count = Module.query.count()
    links_count = ProgrammeModule.query.count()
    return render_template("admin/programmes.html", programmes=programmes,
                            modules_count=modules_count, links_count=links_count)


@admin_bp.route("/users", methods=["GET", "POST"])
@login_required
def users():
    _require_admin()
    if request.method == "POST":
        action = request.form.get("action")

        if action == "create":
            name = request.form.get("name", "").strip()
            role = request.form.get("role")
            password = request.form.get("password", "")
            student_number = request.form.get("student_number", "").strip()
            email = request.form.get("email", "").strip().lower()

            if role not in ("student", "academic_staff", "admin"):
                flash("Choose a valid role.", "error")
            elif role == "student" and not student_number:
                flash("A Student account needs a student number.", "error")
            elif role != "student" and not email:
                flash("Academic Staff and System Administrator accounts need an email address.", "error")
            elif student_number and User.query.filter_by(student_number=student_number).first():
                flash("A user with that student number already exists.", "error")
            elif email and User.query.filter_by(email=email).first():
                flash("A user with that email already exists.", "error")
            else:
                u = User(name=name, role=role,
                         student_number=student_number or None,
                         email=email or None)
                u.set_password(password)
                db.session.add(u)
                db.session.commit()
                flash(f"Account created for {name}.", "success")

        elif action == "update_role":
            user_id = request.form.get("user_id")
            new_role = request.form.get("role")
            u = db.session.get(User, user_id)
            if u and _is_main_admin(u) and new_role != "admin":
                flash(f"{u.name} is the main administrator (ADMIN_EMAIL in .env) and stays an admin.", "error")
            elif u and new_role in ("student", "academic_staff", "admin"):
                u.role = new_role
                u.is_approved = True
                db.session.commit()
                flash(f"Updated {u.name}'s role to {new_role}.", "success")

        elif action == "reset_password":
            u = db.session.get(User, request.form.get("user_id"))
            new_pw = request.form.get("new_password", "")
            if not u:
                flash("User not found.", "error")
            elif len(new_pw) < 6:
                flash("Temporary password must be at least 6 characters.", "error")
            else:
                u.set_password(new_pw)
                db.session.commit()
                flash(f"Password reset for {u.name}. Give them the temporary password and ask them to change it "
                      f"(Change password, bottom of the menu).", "success")

        elif action == "delete":
            user_id = request.form.get("user_id")
            u = db.session.get(User, user_id)
            if u:
                if u.id == current_user.id:
                    flash("You can't remove your own account while logged in.", "error")
                elif _is_main_admin(u):
                    flash(f"{u.name} is the main administrator (ADMIN_EMAIL in .env) and cannot be removed.", "error")
                else:
                    try:
                        db.session.delete(u)
                        db.session.commit()
                        flash(f"Deactivated (removed) {u.name}.", "success")
                    except Exception:
                        db.session.rollback()
                        flash(f"Could not remove {u.name} — related records are blocking it.", "error")

        return redirect(url_for("admin.users"))

    all_users = User.query.order_by(User.role, User.name).all()
    assigned_by_lecturer = {
        u.id: {lm.module_code for lm in u.taught_modules}
        for u in all_users if u.role == "academic_staff"
    }
    return render_template("admin/users.html", users=all_users,
                            assigned_by_lecturer=assigned_by_lecturer)


@admin_bp.route("/access-log")
@login_required
def access_log():
    """Who looked at which student's record, and when."""
    _require_admin()
    q = request.args.get("student_number", "").strip()
    query = AccessLog.query
    if q:
        query = query.filter(AccessLog.student_number.contains(q))
    entries = query.order_by(AccessLog.created_at.desc()).limit(300).all()
    return render_template("admin/access_log.html", entries=entries, q=q)


@admin_bp.route("/users/<int:user_id>/modules", methods=["GET", "POST"])
@login_required
def lecturer_modules(user_id):
    """Assign the module(s) a lecturer teaches, on a page of its own with a search box."""
    _require_admin()
    lecturer = User.query.filter_by(id=user_id, role="academic_staff").first_or_404()
    if request.method == "POST":
        codes = set(request.form.getlist("module_codes"))
        LecturerModule.query.filter_by(lecturer_id=lecturer.id).delete()
        for code in codes:
            if db.session.get(Module, code):
                db.session.add(LecturerModule(lecturer_id=lecturer.id, module_code=code))
        db.session.commit()
        flash(f"Saved: {lecturer.name} now teaches {len(codes)} module(s).", "success")
        return redirect(url_for("admin.users"))
    assigned = {lm.module_code for lm in lecturer.taught_modules}
    all_modules = Module.query.order_by(Module.module_code).all()
    return render_template("admin/lecturer_modules.html", lecturer=lecturer,
                           all_modules=all_modules, assigned=assigned)


@admin_bp.route("/requests")
@login_required
def requests_page():
    """Lecturer module requests and admin access requests waiting for a decision."""
    _require_admin()
    pending = AccessRequest.query.filter_by(status="pending").order_by(AccessRequest.created_at).all()
    decided = (AccessRequest.query.filter(AccessRequest.status != "pending")
               .order_by(AccessRequest.decided_at.desc()).limit(50).all())
    deciders = {u.id: u.name for u in User.query.filter(
        User.id.in_({r.decided_by for r in decided if r.decided_by})).all()} if decided else {}
    return render_template("admin/requests.html",
                           module_requests=[r for r in pending if r.request_type == "module"],
                           admin_requests=[r for r in pending if r.request_type == "admin"],
                           decided=decided, deciders=deciders)


@admin_bp.route("/requests/<int:request_id>/<decision>", methods=["POST"])
@login_required
def decide_request(request_id, decision):
    _require_admin()
    if decision not in ("approve", "reject"):
        abort(404)
    r = db.get_or_404(AccessRequest, request_id)
    back = redirect(url_for("admin.requests_page"))
    if r.status != "pending":
        flash("That request was already handled.", "info")
        return back

    user = r.user
    if decision == "approve":
        if r.request_type == "module":
            if user.role != "academic_staff":
                flash(f"{user.name} is no longer a lecturer, so the module cannot be assigned.", "error")
                return back
            if not LecturerModule.query.filter_by(lecturer_id=user.id, module_code=r.module_code).first():
                db.session.add(LecturerModule(lecturer_id=user.id, module_code=r.module_code))
            message = f"{user.name} now teaches {r.module_code}."
        else:
            if user.role != "admin":
                flash(f"{user.name} is no longer an admin account.", "error")
                return back
            user.is_approved = True
            message = f"{user.name} is now a System Administrator."
    else:
        what = r.module_code if r.request_type == "module" else "admin access"
        message = f"Rejected {user.name}'s request for {what}."

    r.status = "approved" if decision == "approve" else "rejected"
    r.decided_at = datetime.utcnow()
    r.decided_by = current_user.id
    db.session.commit()
    flash(message, "success")
    return back
