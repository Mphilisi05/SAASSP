"""
Settings for SAASSP, read from the .env file in the project root
(see .env.example). Anything not set in .env falls back to the defaults here.
"""
import os

from dotenv import load_dotenv
from sqlalchemy.engine import URL

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


def database_uri():
    # PostgreSQL from DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT in .env
    if not os.environ.get("DB_NAME"):
        return None   # app refuses to start without a database
    return URL.create(
        "postgresql+psycopg2",
        username=os.environ.get("DB_USER"),
        password=os.environ.get("DB_PASSWORD"),
        host=os.environ.get("DB_HOST", "localhost"),
        port=int(os.environ.get("DB_PORT", "5432")),
        database=os.environ.get("DB_NAME"),
    ).render_as_string(hide_password=False)

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

    # PostgreSQL - all app data (users, programmes, modules, marks, feedback, chat, logs)
    SQLALCHEMY_DATABASE_URI = database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # test each pooled connection before use, so a restarted DB does not break requests
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}

    # Claude (Anthropic) - powers the per-mark AI feedback and the Advisor chatbot.
    ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
    ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-5-5")
    ANTHROPIC_CHAT_MODEL = os.environ.get("ANTHROPIC_CHAT_MODEL", "") or ANTHROPIC_MODEL

    # The first admin: an account registered with this e-mail becomes an approved
    # System Administrator straight away. Other admins must be approved by an admin.
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "").strip().lower()

    # E-mail for password reset links. Leave MAIL_SERVER empty to print the
    # e-mail in the terminal instead of sending it.
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", "587") or 587)
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_FROM = os.environ.get("MAIL_FROM", "")

    # Six fixed threshold bands (SRS 3.3.1): (low, high, key, label)
    THRESHOLD_BANDS = [
        (75, 100.0001, "very_safe", "Very safe / excellent"),
        (70, 75, "safe", "Safe"),
        (60, 70, "generally_safe", "Generally safe"),
        (50, 60, "pass_some_risk", "Pass, some risk"),
        (40, 50, "danger", "Danger, at risk of failing"),
        (0, 40, "critical", "Critical / failing"),
    ]

    ASSESSMENT_CATEGORIES = ["Tests", "Assignments", "Quizzes", "Practicals", "Tutorials"]
