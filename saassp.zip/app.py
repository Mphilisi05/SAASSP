"""
SAASSP - Smart Academic Advisory & Student Success Platform.

Entry point. Creates the Flask app, connects the database and logins,
registers the routes and starts the server:

    python app.py        or        flask run

Layout:
    templates/          HTML pages (Jinja2), grouped by role
    static/             CSS and images
    backend/routes/     the pages and actions for each role
    backend/services/   DP engine, progress helpers, Claude AI, e-mail, access log
    backend/models.py   database tables
"""
import os

from flask import Flask, flash, redirect, url_for
from flask_login import current_user, logout_user
from sqlalchemy import inspect, text
from sqlalchemy.exc import OperationalError

from backend import db, login_manager

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


def create_app(config_object=None):
    app = Flask(
        __name__,
        static_folder=os.path.join(BASE_DIR, "static"),
        template_folder=os.path.join(BASE_DIR, "templates"),
    )

    if config_object is None:
        from config import Config
        config_object = Config
    app.config.from_object(config_object)
    if not app.config.get("SQLALCHEMY_DATABASE_URI"):
        raise RuntimeError("No database configured. Set DB_NAME, DB_USER, DB_PASSWORD, "
                           "DB_HOST and DB_PORT in .env")

    db.init_app(app)
    login_manager.init_app(app)

    from backend.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    from backend.routes.auth import auth_bp
    from backend.routes.student import student_bp
    from backend.routes.staff import staff_bp
    from backend.routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(staff_bp)
    app.register_blueprint(admin_bp)

    home_for_role = {
        "student": "student.dashboard",
        "academic_staff": "staff.student_list",
        "admin": "admin.programmes",
    }

    @app.context_processor
    def pending_requests_badge():
        # number shown next to "Requests" in an admin's menu
        if current_user.is_authenticated and current_user.is_admin:
            from backend.models import AccessRequest
            return {"pending_request_count": AccessRequest.query.filter_by(status="pending").count()}
        return {"pending_request_count": 0}

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            if current_user.role == "admin" and not current_user.is_approved:
                return redirect(url_for("auth.admin_request"))
            endpoint = home_for_role.get(current_user.role)
            if endpoint:
                return redirect(url_for(endpoint))
            # unknown role: log out instead of looping
            logout_user()
            flash("This account type is no longer in use. Please ask an administrator.", "error")
        return redirect(url_for("auth.login"))

    with app.app_context():
        try:
            db.session.execute(text("SELECT 1"))
        except OperationalError as e:
            raise RuntimeError(f"Could not connect to the database. Check the DB_ settings in .env "
                               f"and that PostgreSQL is running.\n{e.orig}") from None
        # creates only tables that are missing; existing tables and data are left alone
        db.create_all()
        user_columns = {c["name"] for c in inspect(db.engine).get_columns("users")}
        if "is_approved" not in user_columns:
            raise RuntimeError("The database is from an older version. Run: python database/load_data.py")
        promote_main_admin(app)
        app.logger.info("Connected to database %s", db.engine.url.render_as_string(hide_password=True))

    return app


def promote_main_admin(app):
    # the account with ADMIN_EMAIL (from .env) is always an approved admin
    email = app.config.get("ADMIN_EMAIL")
    if not email:
        return
    from backend.models import User
    user = User.query.filter_by(email=email).first()
    if user and not user.is_admin:
        user.role, user.is_approved = "admin", True
        db.session.commit()


if __name__ == "__main__":
    application = create_app()
    application.run(
        host=os.environ.get("FLASK_RUN_HOST", "0.0.0.0"),
        port=int(os.environ.get("FLASK_RUN_PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )
